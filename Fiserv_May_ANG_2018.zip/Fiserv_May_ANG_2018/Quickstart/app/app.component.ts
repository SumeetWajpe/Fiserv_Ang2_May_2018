import { Component } from '@angular/core';
import {Course} from './course.model';

@Component({
  selector: 'my-app',
  template:`
  
  <a routerLink="/users">Users </a> | <a routerLink="/courses"> Courses </a>
  
  <router-outlet></router-outlet>`
  // template:`<users></users>`
//   template: `
//   <!--
//   <img src="{{ImageUrl}}" height="200px" width="300px" />
//   <img [src]="ImageUrl" height="200px" width="300px" />
//  -->

 
//   <h1> {{heading}} </h1>
//  <!-- <input type="button"
//    value="Change Heading !"
//    (click)="ChangeHeading()"
//    />

//    <input type="text" [(ngModel)]="heading" />
//    <input type="text" [value]="heading" 
//    (input)="ChangeHeading($event)" />
//    -->   
//    Is Active ? <input type="checkbox"
//     [(ngModel)]="isActive" />

//    <p *ngIf="isActive">
//    <input type="button" 
//    value="Active/InActive"   
//    />
//    </p>
//  <div>
//  <p *ngFor="let c of courses">
//     <course [coursedetails]="c"></course>
//  </p>
//  </div>
//   `
})
export class AppComponent  { 
    heading:string="";
    isActive:boolean=false;
      courses:Course[] =[
      new Course("C#",5,3.4575,5000),
      new Course("Angular",4,4,5000), 
      new Course("React",2,3,3000), 
      new Course("Redux",5,3,4000), 
      new Course("Bootstrap",3,3,2000)
      ];



      ImageUrl:string="https://cdn-images-1.medium.com/max/1600/0*SnFQ-3TVpHF5jMb6.png";

      ChangeHeading(e:any){
       
        this.heading = e.target.value;
      }
 }
