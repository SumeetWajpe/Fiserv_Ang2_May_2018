"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var course_model_1 = require("./course.model");
var AppComponent = (function () {
    function AppComponent() {
        this.heading = "";
        this.isActive = false;
        this.courses = [
            new course_model_1.Course("C#", 5, 3.4575, 5000),
            new course_model_1.Course("Angular", 4, 4, 5000),
            new course_model_1.Course("React", 2, 3, 3000),
            new course_model_1.Course("Redux", 5, 3, 4000),
            new course_model_1.Course("Bootstrap", 3, 3, 2000)
        ];
        this.ImageUrl = "https://cdn-images-1.medium.com/max/1600/0*SnFQ-3TVpHF5jMb6.png";
    }
    AppComponent.prototype.ChangeHeading = function (e) {
        this.heading = e.target.value;
    };
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        template: "\n  \n  <a routerLink=\"/users\">Users </a> | <a routerLink=\"/courses\"> Courses </a>\n  \n  <router-outlet></router-outlet>"
        // template:`<users></users>`
        //   template: `
        //   <!--
        //   <img src="{{ImageUrl}}" height="200px" width="300px" />
        //   <img [src]="ImageUrl" height="200px" width="300px" />
        //  -->
        //   <h1> {{heading}} </h1>
        //  <!-- <input type="button"
        //    value="Change Heading !"
        //    (click)="ChangeHeading()"
        //    />
        //    <input type="text" [(ngModel)]="heading" />
        //    <input type="text" [value]="heading" 
        //    (input)="ChangeHeading($event)" />
        //    -->   
        //    Is Active ? <input type="checkbox"
        //     [(ngModel)]="isActive" />
        //    <p *ngIf="isActive">
        //    <input type="button" 
        //    value="Active/InActive"   
        //    />
        //    </p>
        //  <div>
        //  <p *ngFor="let c of courses">
        //     <course [coursedetails]="c"></course>
        //  </p>
        //  </div>
        //   `
    })
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map