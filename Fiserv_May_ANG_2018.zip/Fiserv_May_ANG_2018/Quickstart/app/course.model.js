"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Course = (function () {
    function Course(name, duration, rating, price) {
        this.name = name;
        this.duration = duration;
        this.rating = rating;
        this.price = price;
    }
    return Course;
}());
exports.Course = Course;
//# sourceMappingURL=course.model.js.map