import {Component} from '@angular/core';
import { UsersService } from './users.service';

@Component({
    selector:`users`,
    templateUrl:`./app/users.template.html`,
    providers:[UsersService]
})
export class UsersComponent{
    allUsers:any[] = [];
        constructor(public servObj:UsersService){
           var thePromise =     this.servObj.getUsers();// consume
           
           thePromise.then((theResponse)=>{
                this.allUsers = (theResponse.json())
           },(theError)=>{
                console.log(theError);
           });
        }
}