
import {Component,Input} from '@angular/core';

@Component({
        selector:`course`,
        template:`
        <div class="CourseStyle">
        <h1> {{coursedetails.name | uppercase | lowercase }}  </h1>
        
        <b> Duration : </b> {{coursedetails.duration | durationpipe:'hours' }} <br/>
        <b> Price : </b> {{coursedetails.price | currency:'INR':true }} <br/>
        <b> Rating : </b> {{coursedetails.rating | number:'1.1-2' }} <br/>
        {{coursedetails | json }}
      </div>
        `, 
        styles:[
            `
            .CourseStyle{
              background-color:lightblue;
              border:2px solid red;
              border-radius:10px;
              padding:10px;
              margin:10px;
            }      
        
            `
          ]
})
export class CourseComponent{
    @Input()    coursedetails:any={name:"ReactJS",duration:'1 day'};
}