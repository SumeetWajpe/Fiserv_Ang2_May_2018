import {Component} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
@Component({
    selector:`userdetail`,
    template:`<h1> User Details for {{theUserId}} </h1>`,
    
})
export class UserDetailComponent{
    theUserId:number;
    constructor(private currRoute:ActivatedRoute){
            this.currRoute.params.subscribe(
                (p)=>{
                    this.theUserId = p["id"]
                }
            )
    }
   
}