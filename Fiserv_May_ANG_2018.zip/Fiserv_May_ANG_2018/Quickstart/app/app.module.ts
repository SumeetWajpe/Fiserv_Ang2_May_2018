import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {CourseComponent} from './course.component'

import {FormsModule} from '@angular/forms';
import { AppComponent }  from './app.component';
import { DurationPipe } from './duration.pipe';
import { HttpModule } from '@angular/http';
import { UsersComponent } from './users.component';
import {RouterModule, Route} from '@angular/router';
import { UserDetailComponent } from './userdetails.component';


var routes:Route[] = [
{path:`users`,component:UsersComponent},
{path:`courses`,component:CourseComponent},
{path:`user/:id`,component:UserDetailComponent},
{path:`**`,redirectTo:'courses',pathMatch:'full'}
];


@NgModule({
  imports:      [ BrowserModule,
    FormsModule,
    HttpModule, RouterModule.forRoot(routes)
   ],
  declarations: [ AppComponent,
    CourseComponent,
    DurationPipe,
  UsersComponent,UserDetailComponent
  ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
