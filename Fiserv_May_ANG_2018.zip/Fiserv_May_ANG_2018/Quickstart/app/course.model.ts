export class Course{
    constructor(
        public name?:string,
        public duration?:number,
        public rating?:number,
        public price?:number
    ){

    }
}