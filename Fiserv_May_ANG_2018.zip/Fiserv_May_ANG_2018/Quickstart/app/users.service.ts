import {Http} from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class UsersService{

    constructor(public httpObj:Http){}

    getUsers(){
            // make ajax request !
        return  this.httpObj.get('https://api.github.com/users').toPromise()
    }
}