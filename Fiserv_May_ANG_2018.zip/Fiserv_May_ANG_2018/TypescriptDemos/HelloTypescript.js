var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var str = "Hello !"; // Type inference
// x = "Hello !";
var x;
var booleanVar; // type annotation
var s;
var anyType;
anyType = 100;
anyType = "Hi !";
function Add(x, y) {
    return x + y;
}
var result = Add(20, 30);
var cars = ["BMW", "AUDI", "FERARRI"];
var moreCars = new Array("TATA", "MAHINDRA", "MARUTI");
var allCars = cars.concat(moreCars);
// for 
// for - in
// for - of (typescript)
for (var _i = 0, allCars_1 = allCars; _i < allCars_1.length; _i++) {
    var car = allCars_1[_i];
    console.log(car);
}
if (true) {
    var scopedVar = 1000;
    console.log(scopedVar);
}
// Arrow Functions (Lambda Expr)
allCars.forEach(function (theCar) {
    console.log(theCar);
});
// Arrows functions
allCars.forEach(function (theCar) { return console.log(theCar); });
function Emp() {
    var _this = this;
    this.Salary = 100000;
    setTimeout(function () {
        console.log(_this.Salary);
    }, 2000);
}
// Classes
var Car = /** @class */ (function () {
    function Car(n, s) {
        if (n === void 0) { n = "i20"; }
        if (s === void 0) { s = 0; }
        this.name = n;
        this.speed = s;
    }
    Car.prototype.Accelerate = function () {
        return this.name + " is running at " + this.speed + " kmph !";
    };
    return Car;
}());
var carObj = new Car();
carObj.Accelerate();
// carObj.name = "i20";
// carObj.speed = 200;
var JamesBondCar = /** @class */ (function (_super) {
    __extends(JamesBondCar, _super);
    function JamesBondCar(n, s, submerge, nitro) {
        var _this = _super.call(this, n, s) || this;
        _this.canSubmerge = submerge;
        _this.useNitroPower = nitro;
        return _this;
    }
    JamesBondCar.prototype.Accelerate = function () {
        return _super.prototype.Accelerate.call(this) + " Can Submerge ? " + this.canSubmerge + " , Can It Use Nitro : " + this.useNitroPower;
    };
    return JamesBondCar;
}(Car));
var jbc = new JamesBondCar("Houston", 300, true, true);
console.log(jbc.Accelerate());
