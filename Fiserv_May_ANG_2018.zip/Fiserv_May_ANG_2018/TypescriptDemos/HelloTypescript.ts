var str ="Hello !";// Type inference
// x = "Hello !";
var x:number;
var booleanVar:boolean; // type annotation
var s:string;
var anyType:any;
anyType = 100;
anyType = "Hi !";

function Add(x:number,y:number):number{
    return x + y;
}

var result:number = Add(20,30);

var cars:string[] = ["BMW","AUDI","FERARRI"];
var moreCars:Array<string> = new Array<string>("TATA","MAHINDRA","MARUTI");

var allCars = [...cars,...moreCars];

// for 
// for - in
// for - of (typescript)

for(var car of allCars){
    console.log(car)
}

if(true){
    let scopedVar =1000;
    console.log(scopedVar);    
} 



// Arrow Functions (Lambda Expr)


allCars.forEach(function(theCar){
    console.log(theCar);
});

// Arrows functions

allCars.forEach(
    (theCar)=>  console.log(theCar) 
)

function Emp(){
    this.Salary = 100000;      
    setTimeout(()=>{
            console.log(this.Salary);
    },2000)
}


// Classes


class Car{
    private id:number;
    name:string;
    speed:number;
    constructor(n:string="i20",s:number=0){
            this.name = n;
            this.speed = s;
    }

    Accelerate():string{
          return this.name + " is running at " + this.speed + " kmph !"
    }
}

var carObj = new Car();
carObj.Accelerate();
// carObj.name = "i20";
// carObj.speed = 200;
class JamesBondCar extends Car{
    canSubmerge:boolean;
    useNitroPower:boolean;
    constructor(n:string,s:number,submerge:boolean,nitro:boolean){
        super(n,s);
        this.canSubmerge = submerge;
        this.useNitroPower = nitro;
    }
    Accelerate():string{
        return `${super.Accelerate()} Can Submerge ? ${this.canSubmerge} , Can It Use Nitro : ${this.useNitroPower}`;
    }
}

var jbc = new 
JamesBondCar("Houston",300,true,true);
console.log(jbc.Accelerate());

var mulStr = `This
is Multiline
String
Without using new line operator !`



interface IPerson{
    name:string;
    age?:number;
    getDetails():void;
}


class Person implements IPerson{
    name:string;
   
    getDetails(){

    }
}

class EnhancedCar{
    constructor(public name:string,public speed:number){
            
    }
}

var e = new EnhancedCar("i30",300);